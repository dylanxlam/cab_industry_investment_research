=============
API Reference
=============

.. automodule:: stan
   :members: build

.. automodule:: stan.model
   :members: Model

.. automodule:: stan.fit
   :members: Fit

.. automodule:: stan.plugins
   :members: PluginBase
